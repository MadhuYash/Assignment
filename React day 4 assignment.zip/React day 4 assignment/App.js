// import logo from './logo.svg';
import './App.css';
import ClassLifeCycle from './components/assignment/ClassLifeCycle';
import FunctionalUseEffect from './components/assignment/FunctionalUseEffect';
import RenderEmployee from "./components/RenderEmployee";
import UseEffectComponent from "./components/UseEffectComponent";


function App() {
  return (
    <div className="App">
      
         <ClassLifeCycle/>
         <FunctionalUseEffect/>
       
       {/* <RenderEmployee/> */}
       {/* <UseEffectComponent/> */}
       
  
     
    </div>
  );
}
export default App;