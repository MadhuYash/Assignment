import React from 'react';


function Home() {
    return ( 
        <h2>LivingThings</h2>
     );
}

export default Home;