interface Shape {
	
	public void sphereArea(double r);
	
	public void printResult(double r);
	
	public void rectangleArea(double l , double b);
	
	public void coneArea(double r, double h);
	
}
class Sphere1 implements Shape {
	

	@Override
	public void sphereArea(double r) {
		double pi = 3.14, ar = 0;
		ar = 4 * pi * r * r;
		printResult(ar);
	}

	@Override
	public void printResult(double r) {
		System.out.println(r);
	}

	@Override
	public void rectangleArea(double l, double b) {
		double ar = 0.0d;
		ar = l*b;
		printResult(ar);
	}

	@Override
	public void coneArea(double r, double h) {
		double pi=3.14d, ar =0.00d;
		double r2=Math.pow(r,2);
		double h2=Math.pow(h,2);
		double temp1 = r2+h2;
		double temp = Math.sqrt(temp1);
		ar = pi*r*(r+temp);
		printResult(ar);
	}
}
public class FindArea {

	public static void main(String[] args) {
		Shape area = new Sphere1();
		int r = 2,l=10,b=11,h=12;
		area.sphereArea(r);
		area.rectangleArea(l, b);
		area.coneArea(r, h);
	}

}
