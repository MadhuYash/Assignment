class Person {

	private int pid;
	private String personname;
	private String personaddress;

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPersonname() {
		return personname;
	}

	public void setPersonname(String personname) {
		this.personname = personname;
	}

	public String getPersonaddress() {
		return personaddress;
	}

	public void setPersonaddress(String personaddress) {
		this.personaddress = personaddress;
	}

	
		
	}
	class Employee extends Person {

	private int deptname;
	private String location;
	private float salary;
	private float pfdeduction;
	private String post;
	private String email;
	private String dateof_registration;
	private String dateof_joining;
	
	public int getDeptname() {
		return deptname;
	}
	public void setDeptname(int deptname) {
		this.deptname = deptname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public float getPfdeduction() {
		return pfdeduction;
	}
	public void setPfdeduction(float pfdeduction) {
		this.pfdeduction = pfdeduction;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDateof_registration() {
		return dateof_registration;
	}
	public void setDateof_registration(String dateof_registration) {
		this.dateof_registration = dateof_registration;
	}
	public String getDateof_joining() {
		return dateof_joining;
	}
	public void setDateof_joining(String dateof_joining) {
		this.dateof_joining = dateof_joining;
	}
	@Override
	public String toString() {
		return "Employee [deptname=" + deptname + ", location=" + location + ", salary=" + salary + ", pfdeduction="
				+ pfdeduction + ", post=" + post + ", email=" + email + ", dateof_registration=" + dateof_registration
				+ ", dateof_joining=" + dateof_joining + "]";
	}
	
	
	
	
	
	
}
class Customer extends Person {

	private String customermail;
	private String doregistartion;
	
	public String getCustomermail() {
		return customermail;
	}
	public void setCustomermail(String customermail) {
		this.customermail = customermail;
	}
	public String getDoregistartion() {
		return doregistartion;
	}
	public void setDoregistartion(String doregistartion) {
		this.doregistartion = doregistartion;
	}
	@Override
	public String toString() {
		return "Customer [customermail=" + customermail + ", doregistartion=" + doregistartion + "]";
	}

	
}
public class FirstProgram {

	public static void main(String args[]) {
		Employee employee = new Employee();
		employee.setDateof_joining("11/11/22");
		employee.setDateof_registration("11/11/22");
		employee.setDeptname(12);
		employee.setEmail("madhu@yash.com");
		employee.setLocation("AP");
		employee.setPersonaddress("muppalla");
		employee.setPersonname("Madhavi");
		employee.setPfdeduction(2000);
		employee.setPid(101);
		employee.setPost("SD");
		employee.setSalary(10000);
		
		System.out.println(employee);
		
		Customer customer = new Customer();
		customer.setCustomermail("madhu@gmail.com");
        customer.setDoregistartion("monday");
        
        
        System.out.println(customer); 
	}
	
		
	
}


