import java.util.Scanner;
interface Polynomial {
	
    public void readValues(int a,int b);
	
	public void calculateResult(int a, int b);
	
	public void printResult(int c, int d);
	
	
	

}
class PolynomialExample implements Polynomial {

	@Override
	public void readValues(int a, int b) {
		calculateResult(a, b);

	}

	@Override
	public void calculateResult(int a, int b) {
		int c = 0;
		int d = 0;
		c = (a * a) + (b * b) + (2 * a * b);
		d = (a * a * a) + (b * b * b) + 3 * a * (b * b) + 3 * (a * a) * b;
		printResult(c, d);
	}

	@Override
	public void printResult(int c, int d) {
		System.out.println("(a+b)^2= " + c);
		System.out.println("(a+b)^3= " + d);

	}

}

public class FindResult {

	public static void main(String[] args) {
		Polynomial result = new PolynomialExample();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a &b:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		result.readValues(a,b);
		

	}

}