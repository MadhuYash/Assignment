abstract class StringOperation {

	public String  mergeString(String s1, String s2) {
		String s3 = s1+s2;
		return s3;
	}

	public int findChar(String s2, char c) {
		String str = "";
		str+=c;
		int i = s2.indexOf(str);
		return i;

	}

	public char[] getCharArray(String s1) {
		char[] charArray = s1.toCharArray() ;
		return charArray;
	}

}
public class StringOperation2 extends StringOperation{
	
	public static void main(String[] args) {
		StringOperation obj = new StringOperation2();
		String s1 = "Iam ";
		String s2 = "Madhu";
		System.out.println(obj.mergeString(s1, s2));
		System.out.println(obj.findChar(s2, 'M'));
		System.out.println(obj.getCharArray(s1));
	}

}