class Category {
	
	private int categoryId;
	private String categoryName;
	
	
	public Category(int categoryId, String categoryName) {
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}


	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
	}
	
	
	
}

public class Item {

	private int itemid;
	private String itemname;
	private float price;
	private Category category;

	public Item(int itemid, String itemname, float price, Category category) {
		this.itemid = itemid;
		this.itemname = itemname;
		this.price = price;
		this.category = category;

	}
	@Override
	public String toString(){
		return "Item Name="+itemname+"Item Id="+itemid+"Price="+price+"Category"+category;
	}
	

	public static void main(String args[]) {

		Category c1 = new Category(121, "rfyu");
		Item item = new Item(1, "number", (float) 10.0, c1);
		
		System.out.println(item.toString());
	}

}
