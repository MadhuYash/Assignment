import React from "react";

const Peacock = () => {
        return(
            <div>
            <h3>Peacock</h3>
            <p>
                
               Peacock is the national bird of India..
            </p>
        
            </div> 
        )
    
    
}
export default Peacock;