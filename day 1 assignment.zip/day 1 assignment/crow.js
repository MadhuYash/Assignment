import React from "react";

const Crow = () => {
    
        return(
            <div>
            <h3>Crow</h3>
            <p>
                
               Basically crows are super smart..

            </p>
        
            </div> 
        )
    
    
}
export default Crow;