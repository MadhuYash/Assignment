import React from "react";

class Lion extends React.Component {
    render(){
        return(
            <div>
            <h3>Lion</h3>
            <p>
                
               Lion is the king of jungle..

            </p>
        
            </div> 
        )
    }
    
}
export default Lion;