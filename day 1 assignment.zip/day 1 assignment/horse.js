import React from "react";

class Horse extends React.Component {
    render(){
        return(
            <div>

               <h3>Horse</h3>
               <p>

                  Horses can run very fast..

               </p>


            </div>
        
            
        )
    }
    
}
export default Horse;