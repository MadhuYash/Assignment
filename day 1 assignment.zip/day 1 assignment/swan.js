import React from "react";

const Swan = () => {
        return(
            <div>
            <h3>Swan</h3>
            <p>
                
               Swans are ability to swim and fly..

            </p>
        
            </div> 
        )
    
    
}
export default Swan;