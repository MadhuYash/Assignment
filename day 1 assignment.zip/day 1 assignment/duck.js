import React from "react";

const Duck = () => {
    
        return(
            <div>
            <h3>Duck</h3>
            <p>
                
               duck is a small type of swimming bird with short neck and legs..

            </p>
        
            </div> 
        )
    
    
}
export default Duck;