import React from "react";

const Parrot = () => {
   
        return(
            <div>
            <h3>Parrot</h3>
            <p>
                
               Parrots are imitate sounds..

            </p>
        
            </div> 
        )
    
    
}
export default Parrot;