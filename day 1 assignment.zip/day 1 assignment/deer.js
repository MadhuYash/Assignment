import React from "react";

class Deer extends React.Component {
    render(){
        return(
            <div>
            <h3>Deer</h3>
            <p>
                
                Deer is a very beautiful animal..

            </p>
        
            </div>
        )
    }
    
}
export default Deer;