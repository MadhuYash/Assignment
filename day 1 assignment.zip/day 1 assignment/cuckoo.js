import React from "react";

const Cuckoo = () => {
    
        return(
            <div>
            <h3>Cuckoo</h3>
            <p>
                
               cuckoos are well known for laying eggs in the nests of the other birds..

            </p>
        
            </div> 
        )
    
    
}
export default Cuckoo;