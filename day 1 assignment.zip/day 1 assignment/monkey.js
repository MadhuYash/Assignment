import React from "react";

class Monkey extends React.Component {
    render(){
        return(
            <div>
                
                <h3>Monkey</h3>

                <p>


                  Monkeys are some of the most intelligent animals..

                </p>


            </div>
        
            
        )
    }
    
}
export default Monkey;