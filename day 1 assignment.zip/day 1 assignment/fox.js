import React from "react";

class Fox extends React.Component {
    render(){
        return(
            <div>
            <h3>Fox</h3>
            <p>
                
                Fox is a very clever animal..
                
                </p> 



            </div>
        )
    }
    
}
export default Fox;